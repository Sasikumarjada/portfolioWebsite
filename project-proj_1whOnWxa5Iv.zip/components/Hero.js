function Hero() {
    try {
        return (
            <section data-name="hero" data-file="components/Hero.js" className="min-h-screen gradient-bg flex items-center justify-center text-white">
                <div className="container mx-auto px-6 text-center">
                    <div className="fade-in">
                        <h1 className="text-5xl md:text-6xl font-bold mb-4">
                            Sasikumar Jada
                        </h1>
                        <div className="text-xl md:text-2xl mb-6 typing-animation">
                            Python Developer
                        </div>
                        <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto opacity-90">
                            Aspiring Python Developer from Vijayawada, passionate about building scalable backend solutions and data-driven applications
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <button
                                onClick={() => document.getElementById('projects').scrollIntoView({ behavior: 'smooth' })}
                                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors duration-300"
                            >
                                View Projects
                            </button>
                            <button
                                onClick={() => document.getElementById('contact').scrollIntoView({ behavior: 'smooth' })}
                                className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors duration-300"
                            >
                                Get In Touch
                            </button>
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Hero component error:', error);
        reportError(error);
    }
}
