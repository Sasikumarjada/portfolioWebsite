function Skills() {
    try {
        const skillsData = {
            "Languages": ["Python", "HTML", "CSS"],
            "Frameworks": ["Flask", "Django (learning)"],
            "Databases": ["MySQL"],
            "Tools": ["Git", "GitHub", "VS Code"],
            "Libraries": ["Pandas", "NumPy", "Matplotlib"],
            "Strengths": ["Problem Solving", "Debugging", "Fast Learner", "Team Collaboration", "Self-Motivation"]
        };

        return (
            <section data-name="skills" data-file="components/Skills.js" id="skills" className="py-20 bg-gray-50">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-bold text-gray-800 mb-4">Skills & Expertise</h2>
                        <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
                    </div>
                    
                    <div className="max-w-6xl mx-auto">
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                            {Object.entries(skillsData).map(([category, skills], index) => (
                                <div key={index} className="bg-white rounded-lg shadow-lg p-6 hover-lift">
                                    <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
                                        <i data-lucide="star" className="text-blue-600 mr-2 w-5 h-5"></i>
                                        {category}
                                    </h3>
                                    <div className="space-y-3">
                                        {skills.map((skill, skillIndex) => (
                                            <div key={skillIndex} className="flex items-center justify-between">
                                                <span className="text-gray-700">{skill}</span>
                                                <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                                                    <div className="skill-bar h-full"></div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Skills component error:', error);
        reportError(error);
    }
}
