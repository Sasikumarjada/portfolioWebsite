function About() {
    try {
        return (
            <section data-name="about" data-file="components/About.js" id="about" className="py-20 bg-gray-50">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-bold text-gray-800 mb-4">About Me</h2>
                        <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
                    </div>
                    
                    <div className="max-w-4xl mx-auto">
                        <div className="bg-white rounded-lg shadow-lg p-8 hover-lift">
                            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                                I am a passionate Python Developer with hands-on experience in backend development, 
                                RESTful APIs, and data engineering. My expertise spans across building robust Flask web applications 
                                and working with data visualization using powerful libraries like Matplotlib.
                            </p>
                            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
                                With proficiency in Python, MySQL, and Pandas, I focus on creating scalable and testable solutions. 
                                I'm well-versed in Agile workflows and have a strong foundation in data analysis and machine learning concepts.
                            </p>
                            <div className="grid md:grid-cols-2 gap-6 mt-8">
                                <div className="flex items-center space-x-3">
                                    <i data-lucide="map-pin" className="text-blue-600"></i>
                                    <span className="text-gray-700">Based in Vijayawada</span>
                                </div>
                                <div className="flex items-center space-x-3">
                                    <i data-lucide="code" className="text-blue-600"></i>
                                    <span className="text-gray-700">Backend Development</span>
                                </div>
                                <div className="flex items-center space-x-3">
                                    <i data-lucide="database" className="text-blue-600"></i>
                                    <span className="text-gray-700">Data Engineering</span>
                                </div>
                                <div className="flex items-center space-x-3">
                                    <i data-lucide="users" className="text-blue-600"></i>
                                    <span className="text-gray-700">Team Collaboration</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('About component error:', error);
        reportError(error);
    }
}
