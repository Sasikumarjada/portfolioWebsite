function Education() {
    try {
        const educationData = [
            {
                degree: "B.Tech in Artificial Intelligence & Machine Learning",
                institution: "NRI Institute of Technology, JNTUK",
                duration: "2021 – 2025",
                percentage: "81%"
            },
            {
                degree: "Intermediate",
                institution: "Sri Viveka Jr. College",
                duration: "2019 – 2021",
                percentage: "82%"
            },
            {
                degree: "SSC",
                institution: "Z.P.H.S, Pokuru",
                duration: "2018 – 2019",
                percentage: "85%"
            }
        ];

        return (
            <section data-name="education" data-file="components/Education.js" id="education" className="py-20 bg-white">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-bold text-gray-800 mb-4">Education</h2>
                        <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
                    </div>
                    
                    <div className="max-w-4xl mx-auto">
                        <div className="space-y-8">
                            {educationData.map((edu, index) => (
                                <div key={index} className="bg-gray-50 rounded-lg p-6 hover-lift">
                                    <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                                        <div className="flex-1">
                                            <h3 className="text-xl font-semibold text-gray-800 mb-2">
                                                {edu.degree}
                                            </h3>
                                            <p className="text-blue-600 font-medium mb-1">{edu.institution}</p>
                                            <p className="text-gray-600">{edu.duration}</p>
                                        </div>
                                        <div className="mt-4 md:mt-0">
                                            <span className="bg-blue-100 text-blue-800 px-4 py-2 rounded-full font-semibold">
                                                {edu.percentage}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Education component error:', error);
        reportError(error);
    }
}
