function Projects() {
    try {
        const projects = [
            {
                title: "Smart Housing Price Estimator",
                description: "Built a scalable web app using Flask and machine learning to predict house prices. Integrated user-facing components (HTML, CSS, JS) with the Flask backend, performed data preprocessing, feature engineering, and model optimization.",
                technologies: ["Flask", "Machine Learning", "HTML", "CSS", "JavaScript", "Python"],
                githubLink: "https://github.com/Sasikumarjada/Smart-house-price-predictor"
            },
            {
                title: "Personal Expense Tracker",
                description: "Developed a CLI tool to log, view, and analyze expenses using Python and Pandas. Generated spending summaries and visual reports with Matplotlib, enabled persistent storage using CSV files.",
                technologies: ["Python", "Pandas", "Matplotlib", "CSV", "CLI"],
                githubLink: "https://github.com/Sasikumarjada/Smart-house-price-predictor"
            }
        ];

        return (
            <section data-name="projects" data-file="components/Projects.js" id="projects" className="py-20 bg-white">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-bold text-gray-800 mb-4">Featured Projects</h2>
                        <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
                    </div>
                    
                    <div className="max-w-6xl mx-auto">
                        <div className="grid md:grid-cols-2 gap-8">
                            {projects.map((project, index) => (
                                <div key={index} className="bg-gray-50 rounded-lg shadow-lg overflow-hidden hover-lift">
                                    <div className="h-48 bg-gradient-to-br from-blue-400 to-purple-500 flex items-center justify-center">
                                        <i data-lucide="code" className="text-white w-16 h-16"></i>
                                    </div>
                                    <div className="p-6">
                                        <h3 className="text-xl font-semibold text-gray-800 mb-3">
                                            {project.title}
                                        </h3>
                                        <p className="text-gray-600 mb-4 leading-relaxed">
                                            {project.description}
                                        </p>
                                        <div className="flex flex-wrap gap-2 mb-4">
                                            {project.technologies.map((tech, techIndex) => (
                                                <span key={techIndex} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                                                    {tech}
                                                </span>
                                            ))}
                                        </div>
                                        <a 
                                            href={project.githubLink}
                                            target="_blank"
                                            rel="noopener noreferrer"
                                            className="inline-flex items-center text-blue-600 hover:text-blue-800 font-medium"
                                        >
                                            <i data-lucide="github" className="w-4 h-4 mr-2"></i>
                                            View on GitHub
                                        </a>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Projects component error:', error);
        reportError(error);
    }
}
