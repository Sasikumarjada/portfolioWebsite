function Footer() {
    try {
        return (
            <footer data-name="footer" data-file="components/Footer.js" className="bg-gray-800 text-white py-8">
                <div className="container mx-auto px-6">
                    <div className="text-center">
                        <p className="text-gray-300">
                            © 2024 Sasikumar Jada. All rights reserved.
                        </p>
                        <p className="text-gray-400 mt-2">
                            Built with passion for Python development
                        </p>
                    </div>
                </div>
            </footer>
        );
    } catch (error) {
        console.error('Footer component error:', error);
        reportError(error);
    }
}
