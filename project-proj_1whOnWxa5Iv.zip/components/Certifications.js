function Certifications() {
    try {
        const certifications = [
            { name: "Python Developer Associate", issuer: "MISAC" },
            { name: "Internet of Things", issuer: "NPTEL" },
            { name: "Introduction to Machine Learning", issuer: "Great Learning" }
        ];

        return (
            <section data-name="certifications" data-file="components/Certifications.js" className="py-20 bg-gray-50">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-bold text-gray-800 mb-4">Certifications</h2>
                        <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
                    </div>
                    
                    <div className="max-w-4xl mx-auto">
                        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                            {certifications.map((cert, index) => (
                                <div key={index} className="bg-white rounded-lg shadow-lg p-6 text-center hover-lift">
                                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                        <i data-lucide="award" className="text-blue-600 w-8 h-8"></i>
                                    </div>
                                    <h3 className="text-lg font-semibold text-gray-800 mb-2">
                                        {cert.name}
                                    </h3>
                                    <p className="text-blue-600 font-medium">{cert.issuer}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Certifications component error:', error);
        reportError(error);
    }
}
