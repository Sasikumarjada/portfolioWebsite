function Contact() {
    try {
        return (
            <section data-name="contact" data-file="components/Contact.js" id="contact" className="py-20 bg-white">
                <div className="container mx-auto px-6">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl font-bold text-gray-800 mb-4">Get In Touch</h2>
                        <div className="w-24 h-1 bg-blue-600 mx-auto"></div>
                    </div>
                    
                    <div className="max-w-4xl mx-auto">
                        <div className="grid md:grid-cols-2 gap-8">
                            <div className="space-y-6">
                                <h3 className="text-2xl font-semibold text-gray-800 mb-6">Let's Connect</h3>
                                <p className="text-gray-600 leading-relaxed">
                                    I'm always open to discussing new opportunities, interesting projects, 
                                    or just having a chat about Python development and technology.
                                </p>
                                
                                <div className="space-y-4">
                                    <div className="flex items-center space-x-4">
                                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                            <i data-lucide="mail" className="text-blue-600 w-6 h-6"></i>
                                        </div>
                                        <div>
                                            <p className="font-semibold text-gray-800">Email</p>
                                            <a href="mailto:sasikumarjada44@gmail.com" className="text-blue-600 hover:text-blue-800">
                                                sasikumarjada44@gmail.com
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <div className="flex items-center space-x-4">
                                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                            <i data-lucide="phone" className="text-blue-600 w-6 h-6"></i>
                                        </div>
                                        <div>
                                            <p className="font-semibold text-gray-800">Phone</p>
                                            <a href="tel:+918639763682" className="text-blue-600 hover:text-blue-800">
                                                +91 8639763682
                                            </a>
                                        </div>
                                    </div>
                                    
                                    <div className="flex items-center space-x-4">
                                        <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                                            <i data-lucide="map-pin" className="text-blue-600 w-6 h-6"></i>
                                        </div>
                                        <div>
                                            <p className="font-semibold text-gray-800">Location</p>
                                            <p className="text-gray-600">Vijayawada</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="bg-gray-50 rounded-lg p-8">
                                <h3 className="text-xl font-semibold text-gray-800 mb-6">Connect on Social</h3>
                                <div className="space-y-4">
                                    <a 
                                        href="https://www.linkedin.com/in/sasikumar-jada/" 
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center space-x-3 text-gray-700 hover:text-blue-600 transition-colors"
                                    >
                                        <i data-lucide="linkedin" className="w-5 h-5"></i>
                                        <span>LinkedIn Profile</span>
                                    </a>
                                    <a 
                                        href="https://github.com/Sasikumarjada" 
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center space-x-3 text-gray-700 hover:text-blue-600 transition-colors"
                                    >
                                        <i data-lucide="github" className="w-5 h-5"></i>
                                        <span>GitHub Profile</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    } catch (error) {
        console.error('Contact component error:', error);
        reportError(error);
    }
}
