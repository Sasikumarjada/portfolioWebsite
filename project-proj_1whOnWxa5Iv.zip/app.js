function App() {
    try {
        React.useEffect(() => {
            lucide.createIcons();
        }, []);

        return (
            <div data-name="app" data-file="app.js" className="scroll-smooth">
                <Header />
                <Hero />
                <About />
                <Education />
                <Skills />
                <Projects />
                <Certifications />
                <Contact />
                <Footer />
            </div>
        );
    } catch (error) {
        console.error('App component error:', error);
        reportError(error);
    }
}

ReactDOM.render(React.createElement(App), document.getElementById('root'));
